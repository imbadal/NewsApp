package com.example.newsapp.dagger;

import com.example.newsapp.MainActivity;

import dagger.Component;

@Component(modules = {NetworkModule.class,AppModule.class})
public interface AppComponent {
    void  inject(MainActivity mainActivity);
}
