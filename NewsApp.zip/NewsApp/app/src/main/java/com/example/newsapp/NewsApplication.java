package com.example.newsapp;

import android.app.Application;

import com.example.newsapp.dagger.AppComponent;

import dagger.internal.DaggerCollections;

public class NewsApplication extends Application {
    AppComponent appComponent;
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
