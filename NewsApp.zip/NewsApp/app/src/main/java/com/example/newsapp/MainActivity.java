package com.example.newsapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    NewsAdapter adapter;

    String country = "in";
    String key = "b0163361f90e4d51b663eb66acd3ea3f";

    @Inject
    NewsOrg newsOrg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerview_news);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        Call<ModelNews> call = newsOrg.getNews(country, key);
        call.enqueue(new Callback<ModelNews>() {
            @Override
            public void onResponse(Call<ModelNews> call, Response<ModelNews> response) {
                if (!response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Code: " + response.message(), Toast.LENGTH_SHORT).show();
                    return;
                }

                ModelNews news = response.body();

                List<ModelArticle> articles = news.getArticles();

                setUpRecyclerView(articles);

                for (ModelArticle modelArticle : articles) {

                    Log.d("get_news", "onResponse:" + modelArticle.getTitle() + "\n\n");

                }

            }

            @Override
            public void onFailure(Call<ModelNews> call, Throwable t) {

            }
        });

    }

    private void setUpRecyclerView(List<ModelArticle> articles) {

        adapter = new NewsAdapter(articles);
        recyclerView.setAdapter(adapter);

    }


}
