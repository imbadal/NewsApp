package com.example.newsapp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    List<ModelArticle> newsList = new ArrayList<>();

    public NewsAdapter(List<ModelArticle> newsList) {
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.news_item, viewGroup, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder newsViewHolder, int i) {

        newsViewHolder.textViewTitle.setText(newsList.get(i).getTitle());
        newsViewHolder.textViewDesc.setText(newsList.get(i).getDescription());
        Glide.with(newsViewHolder.itemView)
                .load(newsList.get(i).urlToImage)
                .placeholder(R.drawable.place_holder)
                .into(newsViewHolder.imageView);

    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public class NewsViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle;
        TextView textViewDesc;
        ImageView imageView;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.title);
            textViewDesc = itemView.findViewById(R.id.desc);
            imageView = itemView.findViewById(R.id.image);

        }
    }

}
